from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.scrollview import ScrollView
from kivy.uix.widget import Widget
from kivy.clock import Clock
from kivy.core.audio import SoundLoader
from kivy.utils import platform
from kivy.storage.jsonstore import JsonStore
from kivy.logger import Logger
from kivy.graphics import Color, Rectangle, Rotate
from kivy.core.window import Window
from kivy.animation import Animation
from kivy.lang import Builder
from kivy.uix.image import Image
from kivy.properties import ObjectProperty  # Добавлен этот импорт
from datetime import datetime, timedelta
import threading
import time
import requests
import feedparser
import json
import re
import random
import os
from gtts import gTTS
try:
    import speech_recognition as sr
    HAS_SPEECH_RECOGNITION = True
except ImportError:
    HAS_SPEECH_RECOGNITION = False

# Устанавливаем цветовую тему (чёрный и жёлтый)
Window.clearcolor = (0.08, 0.08, 0.08, 1)  # Тёмный фон

if platform == 'android':
    from android.permissions import request_permissions, Permission
    from jnius import autoclass

# Запрашиваем разрешения для Android
if platform == 'android':
    request_permissions([
        Permission.RECORD_AUDIO,
        Permission.INTERNET,
        Permission.WAKE_LOCK,
        Permission.VIBRATE
    ])

# 3D эффекты для Альфы
Builder.load_string('''
<AnimeGirlWidget>:
    canvas.before:
        Color:
            rgba: 1, 1, 1, 1
        Rectangle:
            texture: self.texture
            size: self.size
            pos: self.pos
''')


class AnimeGirlWidget(Widget):
    texture = ObjectProperty(None)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.angle = 0
        self.size_hint = (None, None)
        self.size = (300, 300)
        self.pos_hint = {'center_x': 0.5, 'center_y': 0.6}


        self.idle_texture = None
        self.blink_texture = None

        # Загрузка текстур с обработкой ошибок
        try:
            if os.path.exists('3d_girl_idle.png'):
                self.idle_texture = Image(source='3d_girl_idle.png').texture
            if os.path.exists('3d_girl_blink.png'):
                self.blink_texture = Image(source='3d_girl_blink.png').texture
        except Exception as e:
            Logger.error(f"Ошибка загрузки текстур: {str(e)}")

            # Если текстуры не загрузились, создаём заглушку
        if not self.idle_texture or not self.blink_texture:
            with self.canvas:
                Color(1, 0, 0, 1)  # Красный цвет для отсутствующей текстуры
                Rectangle(size=self.size, pos=self.pos)
            return

        self.texture = self.idle_texture

        # Анимация покачивания
        self.anim = Animation(angle=-2, duration=1) + Animation(angle=2, duration=1)
        self.anim.repeat = True
        self.anim.start(self)

        # Запуск мигания
        Clock.schedule_interval(self.trigger_blink, random.uniform(3, 6))

    def trigger_blink(self, dt):
        # Мгновенное изменение текстуры без анимации
        def set_blink(dt):
            self.texture = self.blink_texture

        def reset_blink(dt):
            self.texture = self.idle_texture

        Clock.schedule_once(set_blink, 0)
        Clock.schedule_once(reset_blink, 0.1)


    def on_angle(self, instance, angle):
        self.canvas.before.clear()
        with self.canvas.before:
            Rotate(angle=self.angle, origin=self.center)
            Color(1, 1, 1, 1)
            Rectangle(texture=self.texture, size=self.size, pos=self.pos)


class AnimeAssistantApp(App):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.is_active = False
        self.alarms = []
        self.assistant_name = "Альфа"
        self.current_emotion = "idle"
        self.weather_cache = {}
        self.news_cache = {}
        self.cache_timeout = 1800  # 30 минут кэширования
        self.learned_commands = JsonStore('commands.json')
        self.synonyms = JsonStore('synonyms.json')
        self.news_sources = JsonStore('news_sources.json')
        self.load_data()

    def build(self):
        # Главный контейнер
        self.layout = BoxLayout(orientation='vertical', spacing=10, padding=10)

        # Устанавливаем стильный фон с градиентом
        with self.layout.canvas.before:
            Color(0.08, 0.08, 0.08, 1)
            self.bg = Rectangle(size=Window.size, pos=self.layout.pos)

        # 3D аниме-девочка (единственный экземпляр)
        try:
            self.anime_girl = AnimeGirlWidget()
        except Exception as e:
            Logger.error(f"Ошибка создания виджета: {str(e)}")
            self.anime_girl = Label(text="Ошибка загрузки персонажа")
        self.layout.add_widget(self.anime_girl)

        # Статусная строка с неоновым эффектом
        self.status_label = Label(
            text=f"[color=ffff00]{self.assistant_name}[/color] [color=ffffff]готова к работе![/color]",
            size_hint=(1, 0.08),
            color=(1, 1, 1, 1),
            bold=True,
            font_size='20sp',
            markup=True,
            outline_color=(0, 0, 0, 0.8),
            outline_width=2
        )
        self.layout.add_widget(self.status_label)

        # Кнопка активации с эффектом свечения
        self.btn_activate = Button(
            text="[color=000000]🎤 АКТИВИРОВАТЬ[/color]",
            size_hint=(1, 0.08),
            background_normal='',
            background_color=(1, 0.8, 0, 1),
            color=(0, 0, 0, 1),
            bold=True,
            font_size='18sp',
            markup=True,
            border=(0, 0, 0, 0),
            background_down='atlas://data/images/defaulttheme/button_pressed'
        )
        self.btn_activate.bind(on_press=self.toggle_assistant)
        self.layout.add_widget(self.btn_activate)

        # Поле ввода с стилем "киберпанк"
        self.command_input = TextInput(
            hint_text="Произнесите команду или введите текст...",
            size_hint=(1, 0.12),
            multiline=False,
            background_normal='',
            background_color=(0.15, 0.15, 0.15, 1),
            foreground_color=(1, 0.8, 0, 1),
            hint_text_color=(0.6, 0.6, 0.6, 1),
            cursor_color=(1, 0.8, 0, 1),
            font_size='16sp',
            padding=[10, 10]
        )
        self.command_input.bind(on_text_validate=self.process_text_command)
        self.layout.add_widget(self.command_input)

        # Область вывода с эффектом терминала
        self.response_scroll = ScrollView(
            size_hint=(1, 0.3),
            bar_color=(1, 0.8, 0, 0.5),
            bar_inactive_color=(1, 0.8, 0, 0.2),
            bar_width=6
        )
        self.response_label = Label(
            text="[color=ffff00]>>[/color] [color=ffffff]Система инициализирована...[/color]",
            size_hint_y=None,
            halign='left',
            valign='top',
            color=(1, 1, 1, 1),
            text_size=(Window.width - 20, None),
            markup=True
        )
        self.response_label.bind(texture_size=self.response_label.setter('size'))
        self.response_scroll.add_widget(self.response_label)
        self.layout.add_widget(self.response_scroll)

        # Список будильников с подсветкой
        self.alarms_label = Label(
            text="[color=ffff00]>>[/color] [color=ffffff]Активные будильники: нет[/color]",
            size_hint=(1, 0.15),
            color=(1, 1, 1, 1),
            markup=True,
            font_size='14sp'
        )
        self.layout.add_widget(self.alarms_label)

        # Таймер для проверки будильников
        Clock.schedule_interval(self.check_alarms, 1)

        # Запускаем анимацию дыхания для 3D модели
        self.start_idle_animation()

        return self.layout

    def load_data(self):
        # Загрузка синонимов
        if not self.synonyms.exists('default'):
            self.synonyms.put('default',
                              погода=["погодка", "температура"],
                              будильник=["напоминалка", "таймер"],
                              новости=["сводка", "события"]
                              )

        # Загрузка источников новостей
        if not self.news_sources.exists('default'):
            self.news_sources.put('default',
                                  технологии='https://habr.com/ru/rss/all/',
                                  спорт='https://rsport.ria.ru/export/rss2/archive/index.xml',
                                  политика='https://ria.ru/export/rss2/politics/index.xml'
                                  )

    def start_idle_animation(self):
        # Случайные движения для оживления персонажа
        def random_movement(dt):
            anim = Animation(pos_hint={'center_x': 0.5 + random.uniform(-0.02, 0.02),
                            'center_y': 0.6 + random.uniform(-0.01, 0.01)},
                            duration=random.uniform(2, 4))
            anim.start(self.anime_girl)

        Clock.schedule_interval(random_movement, 5)

    def change_emotion(self, emotion):
        """Меняем эмоцию 3D модели"""
        emotions = {
            "idle": "3d_girl_idle.png",
            "happy": "3d_girl_happy.png",
            "listen": "3d_girl_listen.png",
            "speak": "3d_girl_speak.png"
        }

        if emotion in emotions and emotion != self.current_emotion:
            # Добавить проверку существования виджета
            if not hasattr(self, 'anime_girl') or not self.anime_girl:
                Logger.error("Anime girl widget not initialized")
                return

            try:
                # Предварительно создать объект Image
                img = Image(source=emotions[emotion])
                new_texture = img.texture
                img = None  # Освободить ресурсы

                # Проверить успешность загрузки текстуры
                if not new_texture:
                    raise ValueError("Empty texture loaded")

            except Exception as e:
                Logger.error(f"Emotion texture error ({emotion}): {str(e)}")
                return

            # Отменить предыдущие анимации перед запуском новых
            Animation.cancel_all(self.anime_girl)

            # Обновить текущую эмоцию только после успешной загрузки
            self.current_emotion = emotion
            self.anime_girl.texture = new_texture

            # Анимация с проверкой существования виджета
            if self.anime_girl:
                anim = (Animation(size=(350, 350), duration=0.2)
                        + Animation(size=(300, 300), duration=0.2))
                anim.start(self.anime_girl)

    def toggle_assistant(self, instance):
        if not HAS_SPEECH_RECOGNITION and platform != 'android':
            self.update_ui("Голосовой ввод недоступен. Установите SpeechRecognition")
            return
        self.is_active = not self.is_active
        if self.is_active:
            self.btn_activate.text = "[color=000000]🔴 ДЕАКТИВИРОВАТЬ[/color]"
            self.status_label.text = f"[color=ffff00]{self.assistant_name}[/color] [color=ffffff]слушает...[/color]"
            self.change_emotion("listen")
            self.start_voice_recognition()

            # Анимация активации
            anim = Animation(background_color=(1, 0.2, 0.2, 1), duration=0.3) + \
                   Animation(background_color=(1, 0.8, 0, 1), duration=0.3)
            anim.start(self.btn_activate)
        else:
            self.btn_activate.text = "[color=000000]🎤 АКТИВИРОВАТЬ[/color]"
            self.status_label.text = f"[color=ffff00]{self.assistant_name}[/color] [color=ffffff]готова к работе![/color]"
            self.change_emotion("idle")

    def start_voice_recognition(self):
        if platform == 'android':
            try:
                SpeechRecognizer = autoclass('android.speech.SpeechRecognizer')
                RecognitionListener = autoclass('android.speech.RecognitionListener')

                class MyRecognitionListener(RecognitionListener):
                    def __init__(self, callback):
                        super().__init__()
                        self.callback = callback

                    def onResults(self, results):
                        self.callback(results)

                    def onError(self, error):
                        self.callback(None)

                def recognition_callback(results):
                    if results:
                        matches = results.getStringArrayList(
                            SpeechRecognizer.RESULTS_RECOGNITION
                        )
                        if matches and matches.size() > 0:
                            self.process_command(matches.get(0))

                self.speech_recognizer = SpeechRecognizer.createSpeechRecognizer(
                    autoclass('org.kivy.android.PythonActivity').mActivity
                )
                self.listener = MyRecognitionListener(recognition_callback)
                self.speech_recognizer.setRecognitionListener(self.listener)
                self.speech_recognizer.startListening(
                    autoclass('android.speech.RecognizerIntent')().getVoiceDetailsIntent()
                )
            except Exception as e:
                Logger.error(f"Android voice recognition error: {str(e)}")
                self.update_ui("Ошибка голосового ввода на Android")
            else:
                if HAS_SPEECH_RECOGNITION:
                    try:
                        r = sr.Recognizer()
                        with sr.Microphone() as source:
                            self.status_label.text = f"[color=ffff00]{self.assistant_name}[/color] [color=ffffff]Говорите...[/color]"
                            audio = r.listen(source, timeout=5)

                        try:
                            command = r.recognize_google(audio, language="ru-RU")
                            self.process_command(command)
                        except sr.UnknownValueError:
                            self.update_ui("Не удалось распознать речь")
                        except sr.RequestError:
                            self.update_ui("Ошибка сервиса распознавания")
                    except Exception as e:
                        Logger.error(f"Voice recognition error: {str(e)}")
                        self.update_ui(f"Ошибка микрофона: {str(e)}")
                else:
                    self.update_ui("Голосовой ввод недоступен")
    def process_text_command(self, instance):
        command = self.command_input.text
        self.command_input.text = ""
        self.process_command(command)

    def process_command(self, command):
        response = self.handle_command(command.lower())
        self.update_ui(response)
        self.speak(response)

        # Анимация реакции на команду
        self.change_emotion("speak")
        Clock.schedule_once(lambda dt: self.change_emotion("idle"), 2)

        # Специальные реакции
        if any(word in command for word in ["Привет! Чем могу помочь?", "Здравствуйте!", "Слушаю вас"]):
            self.anime_girl.texture = Image(source="3d_girl_wave.png").texture
            Clock.schedule_once(lambda dt: self.change_emotion("idle"), 1)
        elif any(word in command for word in ["спасибо", "молодец"]):
            self.change_emotion("happy")
            Clock.schedule_once(lambda dt: self.change_emotion("idle"), 3)

    def handle_command(self, command):
        # Проверка изученных команд
        for key in self.learned_commands:
            if key in command:
                return self.learned_commands.get(key)['response']

        # Обработка основных команд
        if self.match_command(command, 'будильник'):
            return self.handle_alarm(command)

        if self.match_command(command, 'погода'):
            return self.handle_weather(command)

        if self.match_command(command, 'новости'):
            return self.handle_news(command)

        if 'научи команде' in command:
            return self.learn_command(command)

        if 'покажи будильники' in command:
            return self.show_alarms()

        if 'удали будильник' in command:
            return self.delete_alarm(command)
        if 'очисти кэш' in command:
            return self.clear_cache()

        return "Научите команде ... ответ ..., чтобы добавить новую команду в список"

    def match_command(self, command, keyword):
        synonyms = self.synonyms.get('default').get(keyword, [])
        return any(syn in command for syn in synonyms + [keyword])

    def handle_alarm(self, command):
        time_match = re.search(r'(\d{1,2}):?(\d{2})', command)
        if time_match:
            hour = int(time_match.group(1))
            minute = int(time_match.group(2))
            self.alarms.append({
                'time': f"{hour:02d}:{minute:02d}",
                'triggered': False
            })
            self.save_alarms()
            return f"Будильник на {hour:02d}:{minute:02d} установлен!"
        return "Неверный формат времени"

    def handle_weather(self, command):
        city = re.split(r'погода в?', command)[-1].strip()
        if not city:
            city = "Москва"
        return self.get_weather(city)

    def handle_news(self, command):
        category = next((k for k in self.news_sources.get('default') if k in command), 'технологии')
        return self.get_news(category)

    def learn_command(self, command):
        try:
            parts = command.split('научи команде', 1)[1].split('ответ', 1)
            if len(parts) == 2:
                cmd = parts[0].strip()
                response = parts[1].strip()
                self.learned_commands.put(cmd, response=response)
                return f"Команда '{cmd}' сохранена!"
        except:
            return "Ошибка формата. Используйте: 'научи команде [команда] ответ [ответ]'"

    def show_alarms(self):
        if not self.alarms:
            return "Нет активных будильников"
        return "\n".join([f"{i + 1}. {a['time']}" for i, a in enumerate(self.alarms)])

    def delete_alarm(self, command):
        try:
            num = int(re.search(r'\d+', command).group())
            if 1 <= num <= len(self.alarms):
                del self.alarms[num - 1]
                self.save_alarms()
                return f"Будильник {num} удален"
        except:
            return "Ошибка. Укажите номер будильника"

    def get_weather(self, city):
        try:
            # Проверяем кэш
            cache_key = city.lower()
            if cache_key in self.weather_cache:
                cached_time, cached_data = self.weather_cache[cache_key]
                if time.time() - cached_time < self.cache_timeout:
                    return cached_data

            # Если нет в кэше или кэш устарел
            params = {
                'q': city,
                'appid': 'd9f39fa1c96da6377246b0f841442f09',
                'units': 'metric',
                'lang': 'ru'
            }
            response = requests.get("http://api.openweathermap.org/data/2.5/weather", params=params)
            data = response.json()
            temp = data['main']['temp']
            desc = data['weather'][0]['description']
            result = f"В {city} {desc}, температура {temp}°C"

            # Обновляем кэш
            self.weather_cache[cache_key] = (time.time(), result)
            return result
        except Exception as e:
            Logger.error(f"Weather error: {str(e)}")
            # Пробуем вернуть кэшированные данные, если есть
            if cache_key in self.weather_cache:
                return self.weather_cache[cache_key][1] + " (данные из кэша)"
            return "Ошибка получения погоды"

    def get_news(self, category):
        try:
            # Проверяем кэш
            if category in self.news_cache:
                cached_time, cached_data = self.news_cache[category]
                if time.time() - cached_time < self.cache_timeout:
                    return cached_data

            # Если нет в кэше или кэш устарел
            url = self.news_sources.get('default').get(category)
            feed = feedparser.parse(url)
            result = "\n".join([e.title for e in feed.entries[:3]])

            # Обновляем кэш
            self.news_cache[category] = (time.time(), result)
            return result
        except Exception as e:
            Logger.error(f"News error: {str(e)}")
            # Пробуем вернуть кэшированные данные, если есть
            if category in self.news_cache:
                return self.news_cache[category][1] + "\n(данные из кэша)"
            return "Новости недоступны"

    def check_alarms(self, dt):
        now = datetime.now().strftime("%H:%M")
        for alarm in self.alarms:
            if alarm['time'] == now and not alarm['triggered']:
                self.trigger_alarm(alarm)
                alarm['triggered'] = True

    def trigger_alarm(self, alarm):
        self.speak(f"Будильник на {alarm['time']}!")
        if platform == 'android':
            vibrator = autoclass('android.os.Vibrator')
            context = autoclass('org.kivy.android.PythonActivity').mActivity
            vibrator.vibrate(context.getSystemService('vibrator'), 1000)

    def speak(self, text):
        def _speak():
            try:
                filename = f"speech_{random.randint(0, 10000)}.mp3"
                tts = gTTS(text=text, lang='ru')
                tts.save(filename)

                # Ожидаем завершения записи файла
                while not os.path.exists(filename):
                    time.sleep(0.1)

                sound = SoundLoader.load(filename)
                if sound:
                    sound.bind(on_stop=lambda x: os.remove(filename))
                    sound.play()
                else:
                    os.remove(filename)

            except Exception as e:
                Logger.error(f"Ошибка синтеза речи: {str(e)}")
                try:
                    if os.path.exists(filename):
                        os.remove(filename)
                except:
                    pass

            threading.Thread(target=_speak, daemon=True).start()
    def clear_cache(self):
        self.weather_cache = {}
        self.news_cache = {}
        return "Кэш очищен"

    def save_alarms(self):
        with open('alarms.json', 'w') as f:
            json.dump(self.alarms, f)

    def load_alarms(self):
        try:
            with open('alarms.json', 'r') as f:
                self.alarms = json.load(f)
        except:
            self.alarms = []

    def update_ui(self, text):
        current_text = self.response_label.text
        new_text = f"[color=ffff00]>>[/color] [color=ffffff]{text}[/color]\n{current_text}"
        self.response_label.text = new_text

        alarms_text = "[color=ffff00]>>[/color] [color=ffffff]Активные будильники:[/color]"
        alarms_text += "\n".join([f"[color=ffff00]-[/color] [color=ffffff]{a['time']}[/color]"
                                for a in self.alarms]) if self.alarms else " [color=ffffff]нет[/color]"
        self.alarms_label.text = alarms_text

    def on_pause(self):
        self.save_alarms()
        return True

    def on_resume(self):
        self.load_alarms()
        self.update_ui("")


if __name__ == '__main__':
    AnimeAssistantApp().run()